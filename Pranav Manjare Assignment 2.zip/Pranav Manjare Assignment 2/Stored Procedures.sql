--Stored Procedure: InsertOrderDetails

CREATE PROCEDURE InsertOrderDetails
    @OrderID INT,
    @ProductID INT,
    @UnitPrice MONEY = NULL,
    @Quantity INT,
    @Discount FLOAT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentStock INT;
    DECLARE @ReorderLevel INT;
    DECLARE @ActualUnitPrice MONEY;

    -- Get current stock and reorder level
    SELECT 
        @CurrentStock = p.SafetyStockLevel, -- Assuming this acts like UnitsInStock
        @ReorderLevel = p.ReorderPoint,
        @ActualUnitPrice = ISNULL(@UnitPrice, p.StandardCost) -- Default UnitPrice if not provided
    FROM Production.Product p
    WHERE p.ProductID = @ProductID;

    -- Check if product exists
    IF @CurrentStock IS NULL
    BEGIN
        PRINT 'Invalid ProductID. Product does not exist.';
        RETURN;
    END

    -- Check stock availability
    IF @CurrentStock < @Quantity
    BEGIN
        PRINT 'Not enough stock. Order aborted.';
        RETURN;
    END

    -- Insert into Order Details (assumed table is Sales.SalesOrderDetail)
    INSERT INTO Sales.SalesOrderDetail (
        SalesOrderID,
        ProductID,
        OrderQty,
        UnitPrice,
        UnitPriceDiscount,
        rowguid,
        ModifiedDate
    )
    VALUES (
        @OrderID,
        @ProductID,
        @Quantity,
        @ActualUnitPrice,
        @Discount,
        NEWID(),
        GETDATE()
    );

    -- Check if insert was successful
    IF @@ROWCOUNT = 0
    BEGIN
        PRINT 'Failed to place the order. Please try again.';
        RETURN;
    END

    -- Update stock
    UPDATE Production.Product
    SET SafetyStockLevel = SafetyStockLevel - @Quantity
    WHERE ProductID = @ProductID;

    -- Check stock after update
    SELECT @CurrentStock = SafetyStockLevel
    FROM Production.Product
    WHERE ProductID = @ProductID;

    IF @CurrentStock < @ReorderLevel
    BEGIN
        PRINT 'Warning: Quantity in stock has dropped below the reorder level.';
    END

    PRINT 'Order placed successfully.';
END;



--Stored Procedure: UpdateOrderDetails

CREATE PROCEDURE UpdateOrderDetails
    @OrderID INT,
    @ProductID INT,
    @UnitPrice MONEY = NULL,
    @Quantity INT = NULL,
    @Discount FLOAT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @OldQuantity INT,
        @NewQuantity INT,
        @FinalUnitPrice MONEY,
        @FinalDiscount FLOAT,
        @CurrentStock INT;

    -- Get existing order values
    SELECT 
        @OldQuantity = OrderQty,
        @FinalUnitPrice = ISNULL(@UnitPrice, UnitPrice),
        @FinalDiscount = ISNULL(@Discount, UnitPriceDiscount)
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    -- If order doesn't exist
    IF @OldQuantity IS NULL
    BEGIN
        PRINT 'No such order with the given OrderID and ProductID.';
        RETURN;
    END

    -- Decide final quantity
    SET @NewQuantity = ISNULL(@Quantity, @OldQuantity);

    -- Get current stock
    SELECT @CurrentStock = SafetyStockLevel
    FROM Production.Product
    WHERE ProductID = @ProductID;

    IF @CurrentStock IS NULL
    BEGIN
        PRINT 'Invalid ProductID.';
        RETURN;
    END

    -- Adjust stock: rollback old quantity and subtract new quantity
    DECLARE @StockChange INT = @OldQuantity - @NewQuantity;
    DECLARE @UpdatedStock INT = @CurrentStock + @StockChange;

    IF @UpdatedStock < 0
    BEGIN
        PRINT 'Not enough stock to update the order.';
        RETURN;
    END

    -- Perform the update
    UPDATE Sales.SalesOrderDetail
    SET 
        OrderQty = @NewQuantity,
        UnitPrice = @FinalUnitPrice,
        UnitPriceDiscount = @FinalDiscount,
        ModifiedDate = GETDATE()
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    -- Update product stock
    UPDATE Production.Product
    SET SafetyStockLevel = @UpdatedStock
    WHERE ProductID = @ProductID;

    PRINT 'Order updated successfully.';
END;



--Stored Procedure: GetOrderDetails

CREATE PROCEDURE GetOrderDetails
    @OrderID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if records exist for the given OrderID
    IF NOT EXISTS (
        SELECT 1 
        FROM Sales.SalesOrderDetail 
        WHERE SalesOrderID = @OrderID
    )
    BEGIN
        PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR) + ' does not exist';
        RETURN 1;
    END

    -- If records exist, return them
    SELECT *
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID;
END;



--Stored Procedure: DeleteOrderDetails

CREATE PROCEDURE DeleteOrderDetails
    @OrderID INT,
    @ProductID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the given OrderID and ProductID exist together in the order details
    IF NOT EXISTS (
        SELECT 1 
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID AND ProductID = @ProductID
    )
    BEGIN
        PRINT 'Error: Either the OrderID does not exist or the ProductID is not part of this order.';
        RETURN -1;
    END

    -- Delete the matching order detail
    DELETE FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    PRINT 'Order detail deleted successfully.';
END;
