--Trigger 1: Delete Order


CREATE TRIGGER trg_DeleteOrderCascade
ON Orders
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Delete corresponding order details
    DELETE FROM [Order Details]
    WHERE OrderID IN (SELECT OrderID FROM DELETED);

    -- Now delete from Orders table
    DELETE FROM Orders
    WHERE OrderID IN (SELECT OrderID FROM DELETED);

    PRINT 'Order and its details successfully deleted.';
END;




--Trigger 2: Validate Stock Before Inserting Order Detail


CREATE TRIGGER trg_CheckStockBeforeInsert
ON [Order Details]
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT i.ProductID
        FROM INSERTED i
        JOIN Products p ON i.ProductID = p.ProductID
        WHERE i.Quantity > p.UnitsInStock
    )
    BEGIN
        PRINT 'Order could not be filled due to insufficient stock.';
        RETURN;
    END

    INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
    SELECT OrderID, ProductID, UnitPrice, Quantity, Discount
    FROM INSERTED;

    UPDATE p
    SET p.UnitsInStock = p.UnitsInStock - i.Quantity
    FROM Products p
    JOIN INSERTED i ON p.ProductID = i.ProductID;

    PRINT 'Order placed and stock updated.';
END;



--Sample Data for Testing

INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
VALUES (10248, 1, 10.00, 5, 0.0);

INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
VALUES (10248, 1, 10.00, 100, 0.0);