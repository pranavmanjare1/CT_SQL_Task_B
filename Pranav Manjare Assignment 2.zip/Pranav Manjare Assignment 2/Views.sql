--View: vwCustomerOrders

CREATE VIEW vwCustomerOrders AS
SELECT 
    s.Name AS CompanyName,
    soh.SalesOrderID AS OrderID,
    soh.OrderDate,
    sod.ProductID,
    p.Name AS ProductName,
    sod.OrderQty AS Quantity,
    sod.UnitPrice,
    (sod.OrderQty * sod.UnitPrice) AS QuantityPrice
FROM Sales.SalesOrderHeader soh
JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
JOIN Production.Product p ON sod.ProductID = p.ProductID
JOIN Sales.Customer c ON soh.CustomerID = c.CustomerID
JOIN Sales.Store s ON c.StoreID = s.BusinessEntityID
WHERE c.StoreID IS NOT NULL;  

SELECT * FROM dbo.vwCustomerOrders



--View: vwCustomerOrders_YesterdayOnly

CREATE VIEW vwCustomerOrders_YesterdayOnly AS
SELECT 
    s.Name AS CompanyName,
    soh.SalesOrderID AS OrderID,
    soh.OrderDate,
    sod.ProductID,
    p.Name AS ProductName,
    sod.OrderQty AS Quantity,
    sod.UnitPrice,
    (sod.OrderQty * sod.UnitPrice) AS QuantityPrice
FROM Sales.SalesOrderHeader soh
JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
JOIN Production.Product p ON sod.ProductID = p.ProductID
JOIN Sales.Customer c ON soh.CustomerID = c.CustomerID
JOIN Sales.Store s ON c.StoreID = s.BusinessEntityID
WHERE c.StoreID IS NOT NULL
  AND CAST(soh.OrderDate AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);




SELECT * FROM vwCustomerOrders_YesterdayOnly;




--View: MyProducts

CREATE VIEW MyProducts AS
SELECT 
    p.ProductID,
    p.Name AS ProductName,
    p.Size + ' ' + p.WeightUnitMeasureCode AS QuantityPerUnit, 
    p.StandardCost AS UnitPrice,
    s.Name AS CompanyName, 
    c.Name AS CategoryName
FROM Production.Product p
JOIN Production.ProductSubcategory sc ON p.ProductSubcategoryID = sc.ProductSubcategoryID
JOIN Production.ProductCategory c ON sc.ProductCategoryID = c.ProductCategoryID
JOIN Purchasing.ProductVendor pv ON p.ProductID = pv.ProductID
JOIN Purchasing.Vendor s ON pv.BusinessEntityID = s.BusinessEntityID
WHERE p.DiscontinuedDate IS NULL; 


SELECT * FROM MyProducts;