--Function 1: Return Date in MM/DD/YYYY Format

CREATE FUNCTION dbo.fn_FormatDate_MMDDYYYY (
    @InputDate DATETIME
)
RETURNS VARCHAR(10)
AS
BEGIN
    RETURN CONVERT(VARCHAR(10), @InputDate, 101);  
END;

SELECT dbo.fn_FormatDate_MMDDYYYY('2006-11-21 23:34:05.920') AS FormattedDate;





--Function 2: Return Date in YYYYMMDD Format

CREATE FUNCTION dbo.fn_FormatDate_YYYYMMDD (
    @InputDate DATETIME
)
RETURNS VARCHAR(8)
AS
BEGIN
    RETURN CONVERT(VARCHAR(8), @InputDate, 112);  
END;

SELECT dbo.fn_FormatDate_YYYYMMDD('2006-11-21 23:34:05.920') AS FormattedDate;


